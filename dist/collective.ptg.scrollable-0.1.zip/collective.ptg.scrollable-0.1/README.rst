collective.ptg.scrollable
=========================

scrollable display type for collective.plonetruegallery based on the scrollable jQueryTools plugin

You might soon find a demo here: http://products.medialog.no/galleries/scrollable